import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Servidor {
    public static void main(String[] args) throws Exception {
        try {
            Calculadora calculadora = new Calculadora();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.bind("Calculadora", calculadora);
            System.out.println("Servidor RMI pronto.");
        } catch (Exception e) {
            System.err.println("Erro no servidor: " + e.toString());
            e.printStackTrace();
        }
    }
}