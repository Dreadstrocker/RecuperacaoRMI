import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class HotelServer {
    public static void main(String[] args) throws Exception {
        try {
            RoomManager gerente = new RoomManager();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.bind("RoomManager", gerente);
            System.out.println("Servidor RMI pronto.");// TROCAR PARA ALGUNS(MAS) FRASE(S) COERENTES
        } catch (Exception e) {
            System.err.println("Erro no servidor: " + e.toString());
            e.printStackTrace();
        }
    }
}
