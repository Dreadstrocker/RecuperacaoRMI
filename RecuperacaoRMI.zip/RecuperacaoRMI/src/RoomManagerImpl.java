import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RoomManagerImpl extends Remote {
    void gerarQuartosporTipo()throws RemoteException;
    void contarQuartos()throws RemoteException;
}