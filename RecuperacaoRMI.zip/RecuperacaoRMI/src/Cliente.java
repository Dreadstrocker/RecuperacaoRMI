import java.rmi.Naming;

public class Cliente {
    public static void main(String[] args) throws Exception {
        try {
            String objName = "rmi://localhost:1099/Calculadora";
            ICalculadora calculadora = (ICalculadora) Naming.lookup(objName);
            int resultado = calculadora.adicao(5, 3);
            System.out.println("Resultado da soma: " + resultado);
        } catch (Exception e) {
            System.err.println("Erro no cliente: " + e.toString());
            e.printStackTrace();
        }
    }
}