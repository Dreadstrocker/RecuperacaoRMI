import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class RoomManager extends UnicastRemoteObject implements RoomManagerImpl {
    public RoomManager() throws RemoteException {
        super();
    }

    Hotel createHotel() {
        return new Hotel();
    }

    class Hotel {
        private int tipo;


    }

    List<Hotel> quartos = new ArrayList<Hotel>();

//for(Hotel quarto : quartos

    public void gerarQuartosporTipo() {
        int v = 10, w = 20, x = 5, y = 3, z = 2, j = 0, jaux = v + w + x + y + z;
        // nesse caso, valores prontos. Por isso, por enquanto, (jaux > 0) sempre é true.
        for (j = 0; j < 5; j++) {// rodar o ListHotel
            if (jaux > 0) {
                while (v > 0) {

                    Hotel h0 = createHotel();
                    h0.tipo = 0;
                    quartos.add(h0);
                    ;
                    v--;
                }
            } else if (j == 1) {
                while (w > 0) {

                    Hotel h1 = createHotel();
                    h1.tipo = 1;
                    quartos.add(h1);
                    w--;
                }
            } else if (j == 2) {
                while (x > 0) {

                    Hotel h2 = createHotel();
                    h2.tipo = 2;
                    quartos.add(h2);
                    x--;
                }
            } else if (j == 3) {

                while (y > 0) {
                    Hotel h3 = createHotel();
                    h3.tipo = 3;
                    quartos.add(h3);
                    y--;
                }
            } else if (j == 4) {
                while (z > 0) {

                    Hotel h4 = createHotel();
                    h4.tipo = 4;
                    quartos.add(h4);
                    z--;

                }
            }
        }

    }

    public void contarQuartos() {
        int aux = 0;
        int v = 0, w = 0, x = 0, y = 0, z = 0;
        aux = quartos.size();
        for (int j = 0; j < aux; j++) {
            Hotel ht = createHotel();
            Hotel guarda = quartos.get(j);
            if (guarda.tipo == 0) {
                v++;
            } else if (guarda.tipo == 1) {
                w++;
            } else if (guarda.tipo == 2) {
                x++;
            } else if (guarda.tipo == 3) {
                y++;
            } else if (guarda.tipo == 4) {
                z++;                                                                  // Esquece (int)(Math.random() * 101);
            }
            System.out.println("Existem " + v + "quartos, tipo 0, R$:  " + "55 por noite");
            System.out.println("Existem " + w + "quartos, tipo 0, R$:  " + "75 por noite");
            System.out.println("Existem " + x + "quartos, tipo 0, R$:  " + "80 por noite");
            System.out.println("Existem " + y + "quartos, tipo 0, R$:  " + "150 por noite");
            System.out.println("Existem " + z + "quartos, tipo 0, R$:  " + "230 por noite");

        }


    }
}