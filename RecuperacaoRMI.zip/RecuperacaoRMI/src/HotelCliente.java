import java.rmi.Naming;

public class HotelCliente {
    public static void main(String[] args) throws Exception {
        try {
            String objName = "rmi://localhost:1099/RoomManager";
            RoomManagerImpl gerente = (RoomManagerImpl) Naming.lookup(objName);

            //crie um gerador de número int aleatório, e usar para ser a quantidade de quarttos disponíveis na faixa de preço tal
            gerente.gerarQuartosporTipo();
            gerente.contarQuartos();
        } catch (Exception e) {
            System.err.println("Erro no cliente: " + e.toString());
            e.printStackTrace();
        }
    }
}