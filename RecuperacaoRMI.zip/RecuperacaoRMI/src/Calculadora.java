import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Calculadora extends UnicastRemoteObject implements ICalculadora {
    public Calculadora() throws RemoteException {
        super();
    }

    @Override
    public int adicao(int a, int b) throws RemoteException {
        return a + b;
    }

    @Override
    public int subtracao(int a, int b) throws RemoteException {
        return a - b;
    }

    @Override
    public int multiplicacao(int a, int b) throws RemoteException {
        return a * b;
    }

    @Override
    public int divisao(int a, int b) throws RemoteException {
        return a / b;
    }
}